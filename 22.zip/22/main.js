'use strict';

const productUl = document.querySelector('.products-list');
const productLi = document.querySelector('.nav-item');
const subProductLi = document.querySelector('.subnav-item');
const userForm = document.querySelector('.user-form');
const formName = document.getElementById('name');
const requiredFields = userForm.querySelectorAll('.required');
const formDataEl = document.querySelector('.form-data');

const EMPTY_FIELD = 'The field is empty';
const INCORRECT_VALUE = 'Incorrect value';

productUl.addEventListener('click', (event) => {
    const activeEl = document.querySelector('.active');
    const activeSubEl = document.querySelector('.sub-active');

    if(event.target.classList.contains('nav-item')) {
        if (activeEl) {
            activeEl.classList.remove('active');
             
        } 
        event.target.classList.add ('active');
    } 

    if(event.target.classList.contains('subnav-item')) { 
        if (activeSubEl) {
            activeSubEl.classList.remove('sub-active');
        } 
        event.target.classList.add ('sub-active');
    } 

    if(event.target.classList.contains('btn-buy')) {
        activeEl.classList.remove('active');
        activeSubEl.classList.remove('sub-active');
        userForm.classList.add('active-form');
    } 
});

function printError(el, errorMessage) {
    if (errorMessage) {
        userForm.elements[el].classList.add('has-error');
    } else {
        userForm.elements[el].classList.remove('has-error');
    }
    userForm.elements[el].parentElement.querySelector('.error-text').textContent = errorMessage;
}

function sendFormToHTML() {
    console.log('valid');

    for (let i = 0; i < userForm.elements.length - 1; i++) {
        const div = document.createElement('div');
        let formElementValue = userForm.elements[i].value;

        // if (userForm.elements[i].type === 'radio') {
        //     formElementValue = userForm.elements['radio'].value;
        // }

        
        
        div.textContent = `${userForm.elements[i].name}: ${formElementValue}`;
        formDataEl.append(div);
    }

    let data = new FormData(userForm);
    let output = "";
    for (const entry of data) {
        output = entry[0] + "=" + entry[1] + "\r";
    };
    log.innerText = output;
    e.preventDefault();
}

userForm.addEventListener('submit', (e) => {
    e.preventDefault();
    let formValid = true;
    let getSelectedValue = document.querySelector( 'input[name="pay-method"]:checked');

    // Check the Errors
    requiredFields.forEach((field) => {
        if (field.value === '') {
            printError(field.id, EMPTY_FIELD);
            formValid = false;
        }

        if (field.getAttribute('type') === 'email' && !field.value.includes('@')) {
            printError(field.id, INCORRECT_VALUE);
            formValid = false;
        }

        // if (field.getAttribute('type') === 'radio:checked') {
        //     printError(field.id, INCORRECT_VALUE);
        //     formValid = false;
        // }

        if( getSelectedValue != null) {   
            printError(field, INCORRECT_VALUE);
            formValid = false;
        }
        
    });



    // Send the Form if the Form is valid
    if (formValid) {
        sendFormToHTML();
    }
});



formName.addEventListener('input', (e) => {
    if (e.target.value.length > 0) {
        printError('name', '');
    }
});

